# Experiment: Reliability Mechanisms in an Event-Driven System

## Aim
To implement and evaluate reliability mechanisms in an event-driven system using retry strategies, a dead-letter queue (DLQ), and idempotency patterns.

## Objectives
1. Implement bounded retries with exponential backoff and jitter.
2. Route messages to a dead-letter queue after retry exhaustion.
3. Make message processing idempotent so duplicate delivery does not repeat side effects.
4. Test successful processing, transient failures, permanent failures, and duplicate messages.
5. Observe delivery attempts, successful processing, duplicate suppression, and DLQ entries.

## Requirements
- Python 3.10+
- No third-party packages required

## Project structure
```text
event_driven_reliability_experiment/
├── src/
│   └── reliability_demo.py
├── tests/
│   └── test_reliability_demo.py
├── results/
│   └── sample_results.txt
├── run_experiment.py
├── requirements.txt
└── README.md
```

## Design
The demo uses an in-memory event queue and a simulated handler. A message has a stable `message_id`, a payload, and an attempt count. The consumer retries failed deliveries up to a configured maximum. Delay is calculated with exponential backoff and optional jitter; the demo defaults to zero jitter so results are reproducible. Once attempts are exhausted, the message is sent to the DLQ. A processed-message store keyed by `message_id` prevents duplicate side effects.

**Important:** This is a teaching simulation, not a production broker. In production, persist the idempotency record and business side effect atomically, use durable broker acknowledgements, and define retention/alerting/replay policies for the DLQ.

## Run the experiment
From this directory:

```bash
python run_experiment.py
```

Run unit tests:

```bash
python -m unittest discover -s tests -v
```

No external services or packages are needed.

## Experimental scenarios
- **Scenario A — transient failure:** `evt-transient` fails twice, then succeeds.
- **Scenario B — permanent failure:** `evt-poison` fails on every attempt and is moved to the DLQ.
- **Scenario C — duplicate delivery:** `evt-duplicate` is delivered twice, but its side effect is applied once.
- **Scenario D — normal event:** `evt-normal` succeeds on its first attempt.

## Expected observations
- Transient failures recover if a later attempt succeeds before the retry limit.
- Exponential backoff grows between retries (e.g. base 0.01 seconds gives 0.01, 0.02, 0.04 seconds).
- Permanently failing messages are isolated in the DLQ after the maximum number of attempts.
- Duplicate deliveries are acknowledged without repeating the business side effect.

## Result interpretation
Compare `delivery_attempts`, `processed_count`, `duplicate_count`, and `dlq_count` in the output. Reliability mechanisms improve resilience but do not guarantee exactly-once delivery across distributed systems. Idempotency typically provides effectively-once business effects when the idempotency record and side effect are handled atomically.
