import unittest
from src.reliability_demo import Message, ReliabilityConsumer


class ReliabilityTests(unittest.TestCase):
    def test_retries_then_succeeds(self):
        calls = {"n": 0}
        def handler(message):
            calls["n"] += 1
            if calls["n"] < 3:
                raise RuntimeError("temporary")
        consumer = ReliabilityConsumer(handler, max_attempts=3, base_delay=0, sleep=lambda _: None)
        self.assertEqual(consumer.consume(Message("a", {})), "processed")
        self.assertEqual(calls["n"], 3)
        self.assertEqual(consumer.stats.processed_count, 1)
        self.assertEqual(consumer.stats.dlq_count, 0)

    def test_exhaustion_sends_to_dlq(self):
        def handler(message):
            raise ValueError("permanent")
        consumer = ReliabilityConsumer(handler, max_attempts=2, base_delay=0, sleep=lambda _: None)
        self.assertEqual(consumer.consume(Message("b", {"x": 1})), "dead_lettered")
        self.assertEqual(consumer.stats.delivery_attempts, 2)
        self.assertEqual(len(consumer.dlq), 1)
        self.assertEqual(consumer.dlq[0]["message_id"], "b")

    def test_duplicate_does_not_repeat_handler(self):
        calls = {"n": 0}
        def handler(message):
            calls["n"] += 1
        consumer = ReliabilityConsumer(handler, base_delay=0, sleep=lambda _: None)
        message = Message("same-id", {"value": 7})
        self.assertEqual(consumer.consume(message), "processed")
        self.assertEqual(consumer.consume(Message("same-id", {"value": 7})), "duplicate")
        self.assertEqual(calls["n"], 1)
        self.assertEqual(consumer.stats.duplicate_count, 1)

    def test_backoff_is_exponential_and_capped(self):
        consumer = ReliabilityConsumer(lambda _: None, base_delay=0.01, max_delay=0.025)
        self.assertAlmostEqual(consumer._backoff(1), 0.01)
        self.assertAlmostEqual(consumer._backoff(2), 0.02)
        self.assertAlmostEqual(consumer._backoff(3), 0.025)

    def test_invalid_attempt_count_rejected(self):
        with self.assertRaises(ValueError):
            ReliabilityConsumer(lambda _: None, max_attempts=0)


if __name__ == "__main__":
    unittest.main()
