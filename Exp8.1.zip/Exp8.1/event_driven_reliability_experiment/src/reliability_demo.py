"""Small, dependency-free simulation of event-driven reliability patterns."""
from __future__ import annotations

from dataclasses import dataclass, field
import random
import time
from typing import Callable, Any


@dataclass
class Message:
    message_id: str
    payload: dict[str, Any]
    attempts: int = 0


@dataclass
class ExperimentStats:
    delivery_attempts: int = 0
    processed_count: int = 0
    duplicate_count: int = 0
    dlq_count: int = 0
    events: list[str] = field(default_factory=list)


class IdempotencyStore:
    """In-memory stand-in for a durable store keyed by message ID."""
    def __init__(self) -> None:
        self._processed: set[str] = set()

    def contains(self, message_id: str) -> bool:
        return message_id in self._processed

    def mark_processed(self, message_id: str) -> None:
        self._processed.add(message_id)


class ReliabilityConsumer:
    def __init__(
        self,
        handler: Callable[[Message], None],
        max_attempts: int = 3,
        base_delay: float = 0.01,
        max_delay: float = 0.1,
        jitter: float = 0.0,
        sleep: Callable[[float], None] = time.sleep,
        rng: random.Random | None = None,
    ) -> None:
        if max_attempts < 1:
            raise ValueError("max_attempts must be at least 1")
        if base_delay < 0 or max_delay < 0 or jitter < 0:
            raise ValueError("delay and jitter values must be non-negative")
        self.handler = handler
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.jitter = jitter
        self.sleep = sleep
        self.rng = rng or random.Random()
        self.idempotency = IdempotencyStore()
        self.dlq: list[dict[str, Any]] = []
        self.stats = ExperimentStats()

    def _backoff(self, retry_number: int) -> float:
        # retry_number starts at 1 for the first retry.
        delay = min(self.max_delay, self.base_delay * (2 ** (retry_number - 1)))
        if self.jitter:
            delay *= self.rng.uniform(max(0.0, 1.0 - self.jitter), 1.0 + self.jitter)
        return delay

    def consume(self, message: Message) -> str:
        if self.idempotency.contains(message.message_id):
            self.stats.duplicate_count += 1
            self.stats.events.append(f"{message.message_id}: duplicate suppressed")
            return "duplicate"

        last_error: Exception | None = None
        for attempt in range(1, self.max_attempts + 1):
            message.attempts = attempt
            self.stats.delivery_attempts += 1
            try:
                self.handler(message)
                # In production, persist this marker atomically with the side effect.
                self.idempotency.mark_processed(message.message_id)
                self.stats.processed_count += 1
                self.stats.events.append(f"{message.message_id}: processed on attempt {attempt}")
                return "processed"
            except Exception as exc:  # demo intentionally models handler failures
                last_error = exc
                self.stats.events.append(
                    f"{message.message_id}: attempt {attempt} failed ({type(exc).__name__}: {exc})"
                )
                if attempt < self.max_attempts:
                    delay = self._backoff(attempt)
                    self.stats.events.append(f"{message.message_id}: retry in {delay:.3f}s")
                    if delay:
                        self.sleep(delay)

        self.dlq.append({
            "message_id": message.message_id,
            "payload": message.payload,
            "attempts": message.attempts,
            "error": repr(last_error),
        })
        self.stats.dlq_count += 1
        self.stats.events.append(f"{message.message_id}: moved to DLQ after {message.attempts} attempts")
        return "dead_lettered"
