from collections import defaultdict
from src.reliability_demo import Message, ReliabilityConsumer


def main() -> None:
    # Simulated transient failures: fail first two calls for this event.
    failures_remaining = defaultdict(int, {"evt-transient": 2, "evt-poison": 99})
    side_effects: list[str] = []

    def handler(message: Message) -> None:
        remaining = failures_remaining[message.message_id]
        if remaining > 0:
            failures_remaining[message.message_id] -= 1
            raise RuntimeError("simulated processing failure")
        side_effects.append(message.message_id)

    consumer = ReliabilityConsumer(
        handler=handler,
        max_attempts=3,
        base_delay=0.01,
        max_delay=0.05,
        jitter=0.0,  # deterministic for this experiment
    )

    scenarios = [
        ("Scenario A: transient failure", Message("evt-transient", {"type": "invoice.created"})),
        ("Scenario B: permanent failure", Message("evt-poison", {"type": "payment.failed"})),
        ("Scenario C: first delivery", Message("evt-duplicate", {"type": "user.registered"})),
        ("Scenario C: duplicate delivery", Message("evt-duplicate", {"type": "user.registered"})),
        ("Scenario D: normal event", Message("evt-normal", {"type": "order.shipped"})),
    ]

    print("EVENT-DRIVEN RELIABILITY EXPERIMENT")
    print("=" * 38)
    for label, message in scenarios:
        outcome = consumer.consume(message)
        print(f"{label}: {message.message_id} -> {outcome}")

    print("\nEVENT LOG")
    print("-" * 38)
    for event in consumer.stats.events:
        print(event)

    print("\nSUMMARY")
    print("-" * 38)
    print(f"Delivery attempts : {consumer.stats.delivery_attempts}")
    print(f"Successfully processed unique events: {consumer.stats.processed_count}")
    print(f"Duplicate deliveries suppressed: {consumer.stats.duplicate_count}")
    print(f"Messages in DLQ   : {consumer.stats.dlq_count}")
    print(f"Business side effects: {len(side_effects)} -> {side_effects}")
    print(f"DLQ contents      : {consumer.dlq}")


if __name__ == "__main__":
    main()
