'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { ReliableEventProcessor } = require('../src/reliability');

const quietLogger = { log() {} };
const noWait = async () => {};

test('retries transient failures and eventually succeeds', async () => {
  let calls = 0;
  const delays = [];
  const processor = new ReliableEventProcessor({
    handler: async () => {
      calls += 1;
      if (calls < 3) throw new Error('temporary');
    },
    maxRetries: 3,
    baseDelayMs: 10,
    wait: async (ms) => delays.push(ms),
    logger: quietLogger
  });

  const result = await processor.process({ idempotencyKey: 'evt-1' });
  assert.equal(result.status, 'success');
  assert.equal(result.attempts, 3);
  assert.equal(calls, 3);
  assert.deepEqual(delays, [10, 20]);
  assert.equal(processor.dlq.length, 0);
});

test('moves a permanently failing event to DLQ after retry limit', async () => {
  let calls = 0;
  const processor = new ReliableEventProcessor({
    handler: async () => {
      calls += 1;
      throw new Error('permanent');
    },
    maxRetries: 2,
    wait: noWait,
    logger: quietLogger
  });

  const result = await processor.process({ idempotencyKey: 'evt-2' });
  assert.equal(result.status, 'dead-lettered');
  assert.equal(result.attempts, 3); // initial attempt + 2 retries
  assert.equal(calls, 3);
  assert.equal(processor.dlq.length, 1);
  assert.equal(processor.dlq[0].event.idempotencyKey, 'evt-2');
  assert.equal(processor.dlq[0].error, 'permanent');
});

test('does not process a successfully completed event twice', async () => {
  let calls = 0;
  const processor = new ReliableEventProcessor({
    handler: async () => { calls += 1; },
    wait: noWait,
    logger: quietLogger
  });

  const event = { idempotencyKey: 'evt-3', payload: 'sample' };
  const first = await processor.process(event);
  const second = await processor.process(event);

  assert.equal(first.status, 'success');
  assert.equal(second.status, 'duplicate');
  assert.equal(calls, 1);
});

test('rejects events without a valid idempotency key', async () => {
  const processor = new ReliableEventProcessor({
    handler: async () => {},
    wait: noWait,
    logger: quietLogger
  });

  await assert.rejects(() => processor.process({ payload: 'missing key' }), {
    name: 'TypeError'
  });
});
