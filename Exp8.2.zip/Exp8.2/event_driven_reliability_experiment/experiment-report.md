# Experiment Report

## Title
Implementation of Reliability Mechanisms in an Event-Driven System

## Aim
To implement reliability mechanisms in an event-driven system using retry strategies, dead-letter queues (DLQ), and idempotency patterns.

## Theory
In an event-driven architecture, producers publish events and consumers process them asynchronously. Failures can occur because of temporary network issues, service unavailability, invalid data, or unexpected application errors. Reliability mechanisms help prevent transient errors from causing message loss and help control repeated deliveries.

### 1. Retry strategy
A retry strategy attempts a failed operation again. Exponential backoff increases the wait between attempts, reducing pressure on an unhealthy service. In this experiment, the delay is:

`delay = min(baseDelay × 2^(retryNumber − 1), maximumDelay)`

The configured retry count means retries after the initial attempt. For example, `maxRetries = 3` allows up to four total attempts.

### 2. Dead-letter queue (DLQ)
If a message fails after the initial attempt and all permitted retries, it is moved to a DLQ. The DLQ preserves the event and error details for inspection, replay, or manual remediation. In this educational implementation, the DLQ is an in-memory array.

### 3. Idempotency
Message brokers may deliver the same event more than once. An idempotent consumer uses a stable idempotency key to recognize an event that has already completed successfully and avoid applying the same business action again. This implementation stores completed keys in a `Set`.

## Requirements
- Node.js version 18 or later
- Basic knowledge of JavaScript and asynchronous functions
- Terminal or command prompt

## Algorithm
1. Receive an event containing a unique `idempotencyKey`.
2. Validate that the key exists.
3. If the key has already completed, mark the delivery as a duplicate and skip processing.
4. Otherwise, invoke the event handler.
5. If successful, record the key and return success.
6. If failed and retries remain, wait using exponential backoff and retry.
7. If all attempts fail, store the event and error details in the DLQ.
8. Report the processing result.

## Procedure
1. Extract the ZIP archive.
2. Open a terminal in the extracted project directory.
3. Run `node src/demo.js` to observe the demonstration.
4. Run `npm test` to execute the automated tests.
5. Compare the output with the expected observations below.

## Test cases and observations

| Test case | Input / condition | Expected result |
|---|---|---|
| Transient failure | Handler fails twice, then succeeds | Third attempt succeeds |
| Permanent failure | Handler fails on every attempt, `maxRetries = 3` | Four total attempts, then event is stored in DLQ |
| Duplicate delivery | Submit a successfully processed key a second time | Second delivery is skipped |
| Missing idempotency key | Event has no key | Input validation throws a `TypeError` |

## Result
The implementation demonstrates bounded retries with exponential backoff, routes exhausted messages to a dead-letter queue, and skips duplicate deliveries for keys that have already completed successfully. Automated tests verify each behavior.

## Conclusion
Retry strategies help recover from transient failures, a DLQ preserves messages that cannot be processed within the retry budget, and idempotency reduces the risk of duplicate business actions. Together, these mechanisms improve the reliability of event-driven processing.

## Precautions and production considerations
- Use a stable event identifier across redeliveries.
- Set a bounded retry limit and a maximum backoff delay.
- Do not retry permanent errors indefinitely; classify errors in a production implementation.
- Persist queues, DLQ entries, and idempotency records in durable storage for restart safety.
- For concurrent consumers, enforce idempotency atomically in a database or use a unique constraint; an in-memory `Set` is not sufficient.
- Add metrics, structured logs, alerting, retention policies, and a controlled DLQ replay procedure.
