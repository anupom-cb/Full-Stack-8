'use strict';

/**
 * In-memory event processor demonstrating:
 *  - bounded exponential-backoff retries,
 *  - dead-letter queue (DLQ),
 *  - idempotency based on event.idempotencyKey.
 *
 * The delay function is injectable so tests can run without waiting.
 */
class ReliableEventProcessor {
  constructor({
    handler,
    maxRetries = 3,
    baseDelayMs = 100,
    maxDelayMs = 2000,
    wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
    logger = console
  }) {
    if (typeof handler !== 'function') {
      throw new TypeError('handler must be a function');
    }
    if (!Number.isInteger(maxRetries) || maxRetries < 0) {
      throw new RangeError('maxRetries must be a non-negative integer');
    }

    this.handler = handler;
    this.maxRetries = maxRetries;
    this.baseDelayMs = baseDelayMs;
    this.maxDelayMs = maxDelayMs;
    this.wait = wait;
    this.logger = logger;
    this.dlq = [];
    this.processedKeys = new Set();
  }

  retryDelay(retryNumber) {
    // retryNumber starts at 1 for the first retry.
    return Math.min(this.baseDelayMs * (2 ** (retryNumber - 1)), this.maxDelayMs);
  }

  async process(event) {
    if (!event || typeof event.idempotencyKey !== 'string' || !event.idempotencyKey) {
      throw new TypeError('event.idempotencyKey must be a non-empty string');
    }

    if (this.processedKeys.has(event.idempotencyKey)) {
      this.logger.log(`[IDEMPOTENCY] Duplicate skipped: ${event.idempotencyKey}`);
      return { status: 'duplicate', key: event.idempotencyKey, attempts: 0 };
    }

    let attempts = 0;
    while (attempts <= this.maxRetries) {
      attempts += 1;
      try {
        await this.handler(event);
        // Mark as completed only after the handler succeeds.
        this.processedKeys.add(event.idempotencyKey);
        this.logger.log(`[SUCCESS] ${event.idempotencyKey} completed on attempt ${attempts}`);
        return { status: 'success', key: event.idempotencyKey, attempts };
      } catch (error) {
        this.logger.log(`[ERROR] ${event.idempotencyKey}, attempt ${attempts}: ${error.message}`);

        if (attempts > this.maxRetries) {
          const deadLetter = {
            event,
            attempts,
            error: error.message,
            failedAt: new Date().toISOString()
          };
          this.dlq.push(deadLetter);
          this.logger.log(`[DLQ] ${event.idempotencyKey} moved to dead-letter queue`);
          return { status: 'dead-lettered', key: event.idempotencyKey, attempts };
        }

        const delayMs = this.retryDelay(attempts);
        this.logger.log(`[RETRY] ${event.idempotencyKey} waiting ${delayMs}ms`);
        await this.wait(delayMs);
      }
    }

    // Defensive fallback; normal control flow returns from the loop.
    throw new Error('Unexpected processor state');
  }
}

module.exports = { ReliableEventProcessor };
