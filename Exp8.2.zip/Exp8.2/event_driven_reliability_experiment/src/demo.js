'use strict';

const { ReliableEventProcessor } = require('./reliability');

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function main() {
  const failuresByKey = new Map([
    ['order-101', 2],       // transient failure: succeeds on attempt 3
    ['order-202', Infinity] // permanent failure: goes to DLQ
  ]);

  const processor = new ReliableEventProcessor({
    maxRetries: 3,
    baseDelayMs: 50,
    maxDelayMs: 250,
    wait: sleep,
    handler: async (event) => {
      const remaining = failuresByKey.get(event.idempotencyKey) ?? 0;
      if (remaining > 0) {
        if (Number.isFinite(remaining)) {
          failuresByKey.set(event.idempotencyKey, remaining - 1);
        }
        throw new Error('Simulated temporary/service failure');
      }
      console.log(`[HANDLER] Applied business action for ${event.idempotencyKey}`);
    }
  });

  console.log('\n=== 1. Retry until success ===');
  await processor.process({ idempotencyKey: 'order-101', type: 'OrderCreated', orderId: 101 });

  console.log('\n=== 2. Duplicate delivery / idempotency ===');
  await processor.process({ idempotencyKey: 'order-101', type: 'OrderCreated', orderId: 101 });

  console.log('\n=== 3. Exhaust retries and route to DLQ ===');
  await processor.process({ idempotencyKey: 'order-202', type: 'OrderCreated', orderId: 202 });

  console.log('\n=== Final summary ===');
  console.log(`Completed idempotency keys: ${[...processor.processedKeys].join(', ') || '(none)'}`);
  console.log(`DLQ message count: ${processor.dlq.length}`);
  console.log(JSON.stringify(processor.dlq, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
