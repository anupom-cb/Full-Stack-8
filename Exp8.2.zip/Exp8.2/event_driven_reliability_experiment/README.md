# Experiment: Reliability Mechanisms in an Event-Driven System

## Aim
To implement reliability mechanisms in an event-driven system using retry strategies, dead-letter queues (DLQ), and idempotency patterns.

## Objectives
1. Simulate an event-driven producer/consumer workflow.
2. Retry transient failures using exponential backoff.
3. Move messages that exceed the retry limit to a dead-letter queue.
4. Prevent duplicate processing with an idempotency key.
5. Verify the behavior with automated tests.

## Requirements
- Node.js 18 or later
- npm (included with Node.js)

No external packages are required.

## Project structure
```text
event-driven-reliability-experiment/
├── src/
│   ├── reliability.js
│   └── demo.js
├── test/
│   └── reliability.test.js
├── package.json
├── experiment-report.md
└── README.md
```

## How to run
Open a terminal in this folder and run:

```bash
node src/demo.js
```

Run the automated tests:

```bash
npm test
```

## Expected behavior
- A transiently failing event is retried and eventually succeeds.
- A permanently failing event is retried up to the configured limit and then placed in the DLQ.
- A duplicate event with the same idempotency key is not processed twice.
- The demo prints processing attempts, retry delays, duplicate detection, and DLQ contents.

## Reliability design
- **Retry:** bounded retries with exponential backoff. The demo uses a short configurable delay so it is practical to run locally.
- **DLQ:** stores messages that cannot be processed after all retries.
- **Idempotency:** records completed event keys and skips duplicate deliveries.
- **Limitations:** this is an in-memory educational simulation, not a durable message broker. Restarting the process clears queues and idempotency records. A production system should use a durable broker/database, monitoring, alerting, and carefully designed retention policies.
